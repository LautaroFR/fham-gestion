<div class="mb-4">
    <label class="block mb-1">Nombre *</label>
    <input name="name" value="<?php echo e(old('name', $customer->name ?? '')); ?>" class="w-full border rounded p-2">
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="mb-4">
    <label class="block mb-1">Teléfono</label>
    <input name="phone" value="<?php echo e(old('phone', $customer->phone ?? '')); ?>" class="w-full border rounded p-2">
</div>

<div class="mb-4">
    <label class="block mb-1">Email</label>
    <input name="email" value="<?php echo e(old('email', $customer->email ?? '')); ?>" class="w-full border rounded p-2">
</div>

<div class="mb-4">
    <label class="block mb-1">Dirección</label>
    <input name="address" value="<?php echo e(old('address', $customer->address ?? '')); ?>" class="w-full border rounded p-2">
</div>

<div class="mb-4">
    <label class="block mb-1">Observaciones</label>
    <textarea name="notes" class="w-full border rounded p-2"><?php echo e(old('notes', $customer->notes ?? '')); ?></textarea>
</div><?php /**PATH C:\Users\Lautaro\OneDrive\Desktop\FHAM\Gestion\fham-gestion\resources\views/customers/form.blade.php ENDPATH**/ ?>