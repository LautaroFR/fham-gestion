<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="max-w-7xl mx-auto py-6">

    <div class="flex justify-between items-center mb-6">

        <div>
            <h2 class="text-2xl font-bold">Clientes</h2>
            <p class="text-gray-500">
                <?php echo e($customers->total()); ?> cliente(s)
            </p>
        </div>

        <a href="<?php echo e(route('customers.create')); ?>"
           class="inline-flex items-center px-4 py-2 bg-blue-600 rounded-md text-sm font-semibold text-white hover:bg-blue-700">
            + Nuevo Cliente
        </a>

    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-300 rounded p-3 mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="w-full bg-white rounded-lg shadow overflow-hidden">

        <thead class="bg-gray-100">

            <tr>

                <th class="p-3 text-left">Cliente</th>

                <th class="p-3 text-left">Teléfono</th>

                <th class="p-3 text-left">Email</th>

                <th class="p-3 text-center">Pedidos</th>

                <th class="p-3 text-right">Facturado</th>

                <th class="p-3 text-right">Pendiente</th>

                <th class="p-3 text-right">Acciones</th>

            </tr>

        </thead>

        <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr class="border-b hover:bg-gray-50">

                <td class="p-3 font-semibold">
<a href="<?php echo e(route('customers.show',$customer)); ?>"
   class="text-blue-600 hover:underline font-semibold">

    <?php echo e($customer->name); ?>


</a>                </td>

                <td class="p-3">
                    <?php echo e($customer->phone); ?>

                </td>

                <td class="p-3">
                    <?php echo e($customer->email); ?>

                </td>

                <td class="p-3 text-center">
                    <?php echo e($customer->orders_count); ?>

                </td>

                <td class="p-3 text-right">

                    $ <?php echo e(number_format($customer->total_sold,0,',','.')); ?>


                </td>

                <td class="p-3 text-right font-semibold text-red-600">

                    $ <?php echo e(number_format($customer->pending,0,',','.')); ?>


                </td>

                <td class="p-3 text-right">

                    <a href="<?php echo e(route('customers.edit',$customer)); ?>"
                       class="text-blue-600 hover:underline">

                        Editar

                    </a>

                    <form
                        method="POST"
                        action="<?php echo e(route('customers.destroy',$customer)); ?>"
                        class="inline">

                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button
                            onclick="return confirm('¿Eliminar cliente?')"
                            class="text-red-600 ml-4 hover:underline">

                            Eliminar

                        </button>

                    </form>

                </td>

            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>

                <td colspan="7"
                    class="text-center p-10 text-gray-500">

                    No hay clientes cargados.

                </td>

            </tr>

        <?php endif; ?>

        </tbody>

    </table>

    <div class="mt-6">

        <?php echo e($customers->links()); ?>


    </div>

</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Lautaro\OneDrive\Desktop\FHAM\Gestion\fham-gestion\resources\views/customers/index.blade.php ENDPATH**/ ?>