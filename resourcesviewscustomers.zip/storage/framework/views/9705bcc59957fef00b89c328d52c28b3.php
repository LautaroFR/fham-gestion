<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="max-w-7xl mx-auto py-6">

    <div class="flex justify-between items-center mb-6">

        <div>

            <h1 class="text-3xl font-bold">

                <?php echo e($customer->name); ?>


            </h1>

            <p class="text-gray-500">

                <?php echo e($customer->phone); ?>


            </p>

            <p class="text-gray-500">

                <?php echo e($customer->email); ?>


            </p>

        </div>

        <a href="<?php echo e(route('customers.edit',$customer)); ?>"
           class="bg-blue-600 text-white px-4 py-2 rounded">

            Editar Cliente

        </a>

    </div>

    <div class="grid grid-cols-3 gap-5 mb-8">

        <div class="bg-white shadow rounded p-5">

            <div class="text-gray-500">

                Pedidos

            </div>

            <div class="text-4xl font-bold">

                <?php echo e($customer->orders_count); ?>


            </div>

        </div>

        <div class="bg-white shadow rounded p-5">

            <div class="text-gray-500">

                Facturado

            </div>

            <div class="text-4xl font-bold">

                $ <?php echo e(number_format($customer->total_sold,0,',','.')); ?>


            </div>

        </div>

        <div class="bg-white shadow rounded p-5">

            <div class="text-gray-500">

                Pendiente

            </div>

            <div class="text-4xl font-bold text-red-600">

                $ <?php echo e(number_format($customer->pending,0,',','.')); ?>


            </div>

        </div>

    </div>

    <div class="bg-white rounded shadow">

        <table class="w-full">

            <thead class="bg-gray-100">

                <tr>

                    <th class="p-3 text-left">Fecha</th>

                    <th class="p-3 text-left">Pedido</th>

                    <th class="p-3 text-right">Precio</th>

                    <th class="p-3 text-left">Estado</th>

                </tr>

            </thead>

            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $customer->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr class="border-b">

                    <td class="p-3">

                        <?php echo e($order->created_at->format('d/m/Y')); ?>


                    </td>

                    <td class="p-3">

                        <?php echo e($order->title); ?>


                    </td>

                    <td class="p-3 text-right">

                        $ <?php echo e(number_format($order->price,0,',','.')); ?>


                    </td>

                    <td class="p-3">

                        <?php echo e($order->status); ?>


                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td colspan="4" class="text-center p-8">

                        Este cliente todavía no tiene pedidos.

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Lautaro\OneDrive\Desktop\FHAM\Gestion\fham-gestion\resources\views/customers/show.blade.php ENDPATH**/ ?>