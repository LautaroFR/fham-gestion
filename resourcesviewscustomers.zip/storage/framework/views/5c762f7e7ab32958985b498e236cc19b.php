<div class="mb-4">
    <label class="block mb-1">Cliente *</label>
    <select name="customer_id" class="w-full border rounded p-2">
        <option value="">Seleccionar cliente</option>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($customer->id); ?>"
                <?php if(old('customer_id', $order->customer_id ?? '') == $customer->id): echo 'selected'; endif; ?>>
                <?php echo e($customer->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="mb-4">
    <label class="block mb-1">Obra / Proyecto</label>
    <input name="project" value="<?php echo e(old('project', $order->project ?? '')); ?>" class="w-full border rounded p-2">
</div>

<div class="mb-4">
    <label class="block mb-1">Ambiente</label>
    <input name="room" value="<?php echo e(old('room', $order->room ?? '')); ?>" placeholder="Cocina, placard, vestidor..." class="w-full border rounded p-2">
</div>

<div class="mb-4">
    <label class="block mb-1">Mueble / Pedido *</label>
    <input name="title" value="<?php echo e(old('title', $order->title ?? '')); ?>" placeholder="Box sommier, cocina, placard..." class="w-full border rounded p-2">
    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <div class="mb-4">
        <label class="block mb-1">Precio total *</label>
        <input name="price" type="number" step="0.01" value="<?php echo e(old('price', $order->price ?? '')); ?>" class="w-full border rounded p-2">
        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-4">
        <label class="block mb-1">Costo estimado</label>
        <input name="cost" type="number" step="0.01" value="<?php echo e(old('cost', $order->cost ?? 0)); ?>" class="w-full border rounded p-2">
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <div class="mb-4">
        <label class="block mb-1">Fecha instalación / entrega</label>
        <input name="delivery_date" type="date" value="<?php echo e(old('delivery_date', $order->delivery_date ?? '')); ?>" class="w-full border rounded p-2">
    </div>

    <div class="mb-4">
        <label class="block mb-1">Estado</label>
        <select name="status" class="w-full border rounded p-2">
            <?php $__currentLoopData = ['Presupuesto','Señado','En producción','Listo','Instalado','Finalizado','Cancelado']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status); ?>" <?php if(old('status', $order->status ?? 'Presupuesto') == $status): echo 'selected'; endif; ?>>
                    <?php echo e($status); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="mb-4">
    <label class="block mb-1">Observaciones</label>
    <textarea name="notes" class="w-full border rounded p-2"><?php echo e(old('notes', $order->notes ?? '')); ?></textarea>
</div><?php /**PATH C:\Users\Lautaro\OneDrive\Desktop\FHAM\Gestion\fham-gestion\resources\views/orders/form.blade.php ENDPATH**/ ?>