<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div class="max-w-7xl mx-auto py-6">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">Pedidos</h2>

        <a href="<?php echo e(route('orders.create')); ?>"
           class="inline-flex items-center px-4 py-2 bg-blue-600 rounded-md font-semibold text-xs text-white uppercase hover:bg-blue-700">
            Nuevo Pedido
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-300 rounded p-3 mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="w-full bg-white rounded shadow">
        <thead>
            <tr class="border-b">
                <th class="p-3 text-left">Fecha</th>
                <th class="p-3 text-left">Cliente</th>
                <th class="p-3 text-left">Pedido</th>
                <th class="p-3 text-right">Precio</th>
                <th class="p-3 text-right">Costo</th>
                <th class="p-3 text-right">Ganancia</th>
                <th class="p-3 text-left">Estado</th>
                <th class="p-3 text-right">Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-b">
                <td class="p-3"><?php echo e($order->created_at->format('d/m/Y')); ?></td>
                <td class="p-3"><?php echo e($order->customer->name); ?></td>
                <td class="p-3"><?php echo e($order->title); ?></td>
                <td class="p-3 text-right">$<?php echo e(number_format($order->price, 0, ',', '.')); ?></td>
                <td class="p-3 text-right">$<?php echo e(number_format($order->cost, 0, ',', '.')); ?></td>
                <td class="p-3 text-right">$<?php echo e(number_format($order->profit, 0, ',', '.')); ?></td>
                <td class="p-3"><?php echo e($order->status); ?></td>
                <td class="p-3 text-right">
                    <a href="<?php echo e(route('orders.edit', $order)); ?>" class="text-blue-600">Editar</a>

                    <form method="POST" action="<?php echo e(route('orders.destroy', $order)); ?>" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('¿Eliminar pedido?')"
                                class="text-red-600 ml-4">
                            Eliminar
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8" class="p-6 text-center text-gray-500">
                    No hay pedidos cargados.
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <div class="mt-6">
        <?php echo e($orders->links()); ?>

    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\Lautaro\OneDrive\Desktop\FHAM\Gestion\fham-gestion\resources\views/orders/index.blade.php ENDPATH**/ ?>